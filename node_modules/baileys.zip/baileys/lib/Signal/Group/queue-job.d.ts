export default function queueJob<T>(bucket: string | number, awaitable: () => Promise<T>): Promise<T>;
//# sourceMappingURL=queue-job.d.ts.map